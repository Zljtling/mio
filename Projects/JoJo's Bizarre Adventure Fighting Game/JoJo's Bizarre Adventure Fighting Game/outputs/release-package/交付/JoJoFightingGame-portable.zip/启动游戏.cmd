@echo off
cd /d "%~dp0"
start "" "%~dp0JoJoFightingGame.exe"
